using System.Collections.Generic;
using OpenTK;
using OpenTK.Input;

namespace Game.Engine.Input
{
    class UserInput
    {
        public UserInput() {

        }

        public void OnUpdate() {
            
        }
    }
}
