﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Game.Engine.Input;

namespace Game.src.GameStates
{
    class PauseMenuState
    {
        private void TrigMenu() {
        
        }
    }
}
